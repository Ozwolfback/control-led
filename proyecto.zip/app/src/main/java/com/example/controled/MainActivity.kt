package com.example.controled

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var ir: ConsumerIrManager? = null

    // Direccion NEC del control de 24 botones (casi siempre 0x00).
    // Si no responde, prueba cambiando los comandos de la tabla de abajo.
    private val address = 0x00

    private data class Key(val label: String, val color: String, val cmd: Int, val dark: Boolean = false)

    // Fila 1: brillo+, brillo-, OFF, ON
    private val row1 = listOf(
        Key("☀↑", "#FFFFFF", 0x3A), Key("☀↓", "#FFFFFF", 0xBA),
        Key("OFF", "#222222", 0x82, true), Key("ON", "#E53935", 0x02, true)
    )
    private val row2 = listOf(
        Key("R", "#E53935", 0x1A), Key("G", "#2E9E4F", 0x9A),
        Key("B", "#2F5FB8", 0xA2), Key("W", "#FFFFFF", 0x22)
    )
    private val rows = listOf(
        listOf(Key("", "#FF4A1C", 0x2A), Key("", "#4CAF50", 0xAA), Key("", "#3D8FE0", 0x92), Key("FLASH", "#9AA0AB", 0x12)),
        listOf(Key("", "#F5821F", 0x0A), Key("", "#5EC8E8", 0x8A), Key("", "#8E2B6B", 0xB2), Key("STROBE", "#9AA0AB", 0x32)),
        listOf(Key("", "#F0B83A", 0x38), Key("", "#1FA8E0", 0xB8), Key("", "#B8245E", 0x78), Key("FADE", "#9AA0AB", 0x08)),
        listOf(Key("", "#FFE81A", 0x18), Key("", "#1F8FC0", 0x98), Key("", "#E0607E", 0x58), Key("SMOOTH", "#9AA0AB", 0x28))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        if (ir?.hasIrEmitter() != true) {
            Toast.makeText(this, "Este celular no tiene emisor IR", Toast.LENGTH_LONG).show()
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F2F2F5"))
            gravity = Gravity.CENTER
            setPadding(24, 48, 24, 24)
        }
        val remote = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 32)
            background = GradientDrawable().apply {
                setColor(Color.WHITE); cornerRadius = 60f; setStroke(10, Color.parseColor("#2B2B2B"))
            }
        }
        remote.addView(makeRow(row1))
        remote.addView(makeRow(row2))
        rows.forEach { remote.addView(makeRow(it)) }
        root.addView(remote, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    private fun makeRow(keys: List<Key>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        keys.forEach { k ->
            val b = Button(this).apply {
                text = k.label
                textSize = if (k.label.length > 3) 10f else 16f
                setTextColor(if (k.dark) Color.WHITE else Color.parseColor("#222222"))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(Color.parseColor(k.color))
                    setStroke(2, Color.parseColor("#33000000"))
                }
                setOnClickListener { it.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); send(k.cmd) }
            }
            val lp = LinearLayout.LayoutParams(0, 0, 1f)
            lp.height = resources.displayMetrics.widthPixels / 5
            lp.setMargins(8, 8, 8, 8)
            row.addView(b, lp)
        }
        return row
    }

    // Protocolo NEC: cabecera 9000/4500us, bits 560us + (560 o 1690), portadora 38 kHz
    private fun send(cmd: Int) {
        val e = ir ?: return
        if (!e.hasIrEmitter()) return
        val bytes = listOf(address, address.inv() and 0xFF, cmd, cmd.inv() and 0xFF)
        val p = ArrayList<Int>()
        p.add(9000); p.add(4500)
        for (byte in bytes) for (i in 0 until 8) {  // LSB primero
            p.add(560)
            p.add(if (((byte shr i) and 1) == 1) 1690 else 560)
        }
        p.add(560); p.add(20000)
        e.transmit(38000, p.toIntArray())
    }
}
